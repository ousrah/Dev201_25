hello
<?php /**PATH D:\projetsLaravel\202\Blog202\resources\views/welcome.blade.php ENDPATH**/ ?>