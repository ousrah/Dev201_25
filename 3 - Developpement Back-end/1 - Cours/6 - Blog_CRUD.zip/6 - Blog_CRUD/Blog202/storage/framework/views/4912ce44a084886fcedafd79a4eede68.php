<h1>
    ceci est un test
</h1>
<?php /**PATH D:\projetsLaravel\202\Blog202\resources\views/test.blade.php ENDPATH**/ ?>