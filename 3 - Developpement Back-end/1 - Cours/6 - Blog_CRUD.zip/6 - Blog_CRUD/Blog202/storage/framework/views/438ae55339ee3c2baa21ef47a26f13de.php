<?php $__env->startSection('title', $post->title); ?>
<?php $__env->startSection('content'); ?>
<?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo e(session('success')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>
<div class="card">
    <div class="card-body">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h1 class="card-title mb-0"><?php echo e($post->title); ?></h1>
            <div>
                <a href="<?php echo e(route('posts.edit', $post)); ?>" class="btn btn-primary">Modifier</a>
                <form action="<?php echo e(route('posts.destroy', $post)); ?>" method="POST" class="d-inline">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger" onclick="return confirm('Êtes-vous sûr de vouloir supprimer cet article?')">Supprimer</button>
                </form>
            </div>
        </div>
        <p class="card-text"><?php echo e($post->content); ?></p>
    </div>
</div>

<div class="mt-4">
    <h3>Commentaires (<?php echo e($post->comments->count()); ?>)</h3>
    <?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card mb-2">
        <div class="card-body">
            <p class="card-text"><?php echo e($comment->content); ?></p>
            <small class="text-muted">
                Posté <?php echo e($comment->created_at->diffForHumans()); ?>

            </small>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <form method="POST" action="/posts/<?php echo e($post->id); ?>/comments" class="mt-4">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <textarea name="content" class="form-control" placeholder="Votre commentaire..." required></textarea>
        </div>
        <button type="submit" class="btn btn-success">Ajouter un commentaire</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\projetsLaravel\202\Blog202\resources\views/posts/show.blade.php ENDPATH**/ ?>