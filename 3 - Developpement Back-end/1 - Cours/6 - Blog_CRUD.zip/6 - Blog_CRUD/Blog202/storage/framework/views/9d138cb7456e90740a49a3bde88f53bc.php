<?php $__env->startSection('title', 'A propos de'); ?>
<?php $__env->startSection('content'); ?>
    <h1>
        mini blog 2025 - Tous les droits sont réservés.
    </h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\projetsLaravel\202\Blog202\resources\views/about.blade.php ENDPATH**/ ?>