<?php $__env->startSection('title', 'Ajouter un article'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <h1 class="mb-4">Ajouter un nouvel article</h1>

    <form method="POST" action="<?php echo e(route('posts.store')); ?>">
        <?php echo csrf_field(); ?>

        <div class="mb-3">
            <label for="title" class="form-label">Titre</label>
            <input type="text" class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="title" name="title"
                value="<?php echo e(old('title')); ?>" required >
            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="mb-3">
            <label for="content" class="form-label">Contenu</label>
            <textarea class="form-control <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="content" name="content" rows="6"
                required><?php echo e(old('content')); ?></textarea>
            <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="mb-3">
            <button type="submit" class="btn btn-success">Publier l'article</button>
            <a href="<?php echo e(route('posts.index')); ?>" class="btn btn-secondary">Annuler</a>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function () {
        $('form').submit(function (e) {
            let isValid = true;

            // Validation du titre
            let title = $('#title').val().trim();
            let titleWords = title.split(/\s+/).filter(word => word.length > 0);
            if (title.length < 3 || title.length > 255 || titleWords.length < 3) {
                isValid = false;
                $('#title').addClass('is-invalid');
                $('#title').next('.invalid-feedback').remove();
                $('#title').after('<div class="invalid-feedback">Le titre doit contenir entre 3 et 255 caractères et au moins 3 mots.</div>');
            } else {
                $('#title').removeClass('is-invalid');
                $('#title').next('.invalid-feedback').remove();
            }

            // Validation du contenu
            let content = $('#content').val().trim();
            if (content.length < 8) {
                isValid = false;
                $('#content').addClass('is-invalid');
                $('#content').next('.invalid-feedback').remove();
                $('#content').after('<div class="invalid-feedback">Le contenu doit contenir au moins 8 caractères.</div>');
            } else {
                $('#content').removeClass('is-invalid');
                $('#content').next('.invalid-feedback').remove();
            }

            if (!isValid) {
                e.preventDefault(); // Empêche l'envoi du formulaire si invalide
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\projetsLaravel\202\Blog202\resources\views/posts/create.blade.php ENDPATH**/ ?>