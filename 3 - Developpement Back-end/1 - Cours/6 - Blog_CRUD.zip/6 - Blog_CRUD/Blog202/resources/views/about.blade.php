@extends('layouts.app')
@section('title', 'A propos de')
@section('content')
    <h1>
        mini blog 2025 - Tous les droits sont réservés.
    </h1>
@endsection
