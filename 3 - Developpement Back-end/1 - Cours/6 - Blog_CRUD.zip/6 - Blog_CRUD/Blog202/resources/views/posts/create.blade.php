@extends('layouts.app')
@section('title', 'Ajouter un article')
@section('content')
<div class="container">
    <h1 class="mb-4">Ajouter un nouvel article</h1>

    <form method="POST" action="{{ route('posts.store') }}">
        @csrf

        <div class="mb-3">
            <label for="title" class="form-label">Titre</label>
            <input type="text" class="form-control @error('title') is-invalid @enderror" id="title" name="title"
                value="{{ old('title') }}" required >
            @error('title')
            <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <div class="mb-3">
            <label for="content" class="form-label">Contenu</label>
            <textarea class="form-control @error('content') is-invalid @enderror" id="content" name="content" rows="6"
                required>{{ old('content') }}</textarea>
            @error('content')
            <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <div class="mb-3">
            <button type="submit" class="btn btn-success">Publier l'article</button>
            <a href="{{ route('posts.index') }}" class="btn btn-secondary">Annuler</a>
        </div>
    </form>
</div>
@endsection
@section('scripts')
<script>
    $(document).ready(function () {
        $('form').submit(function (e) {
            let isValid = true;

            // Validation du titre
            let title = $('#title').val().trim();
            let titleWords = title.split(/\s+/).filter(word => word.length > 0);
            if (title.length < 3 || title.length > 255 || titleWords.length < 3) {
                isValid = false;
                $('#title').addClass('is-invalid');
                $('#title').next('.invalid-feedback').remove();
                $('#title').after('<div class="invalid-feedback">Le titre doit contenir entre 3 et 255 caractères et au moins 3 mots.</div>');
            } else {
                $('#title').removeClass('is-invalid');
                $('#title').next('.invalid-feedback').remove();
            }

            // Validation du contenu
            let content = $('#content').val().trim();
            if (content.length < 8) {
                isValid = false;
                $('#content').addClass('is-invalid');
                $('#content').next('.invalid-feedback').remove();
                $('#content').after('<div class="invalid-feedback">Le contenu doit contenir au moins 8 caractères.</div>');
            } else {
                $('#content').removeClass('is-invalid');
                $('#content').next('.invalid-feedback').remove();
            }

            if (!isValid) {
                e.preventDefault(); // Empêche l'envoi du formulaire si invalide
            }
        });
    });
</script>
@endsection
