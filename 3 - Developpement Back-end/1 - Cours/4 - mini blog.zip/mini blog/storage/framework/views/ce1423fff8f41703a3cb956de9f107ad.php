<!-- resources/views/posts/index.blade.php -->


<?php $__env->startSection('title', 'Liste des articles'); ?>

<?php $__env->startSection('content'); ?>
<h1 class="mb-4">Articles du blog</h1>
<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="card mb-3">
    <div class="card-body">
        <h2 class="card-title"><?php echo e($post->title); ?></h2>
        <p class="card-text"><?php echo e(Str::limit($post->content, 100)); ?></p>
        <a href="/posts/<?php echo e($post->id); ?>" class="btn btn-primary">Lire la suite</a>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\projetsLaravel\202\project2\resources\views/posts/index.blade.php ENDPATH**/ ?>