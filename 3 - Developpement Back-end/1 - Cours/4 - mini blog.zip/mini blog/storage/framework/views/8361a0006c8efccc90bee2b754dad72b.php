<!-- resources/views/posts/index.blade.php -->


<?php $__env->startSection('title', 'Liste des articles'); ?>

<?php $__env->startSection('content'); ?>
<h1 class="mb-4">Mon Mini Blog de test - ISMO 2025</h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\projetsLaravel\202\project2\resources\views/about.blade.php ENDPATH**/ ?>