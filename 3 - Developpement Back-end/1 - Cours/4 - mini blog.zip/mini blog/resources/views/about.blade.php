<!-- resources/views/posts/index.blade.php -->
@extends('layouts.app')

@section('title', 'Liste des articles')

@section('content')
<h1 class="mb-4">Mon Mini Blog de test - ISMO 2025</h1>
@endsection
